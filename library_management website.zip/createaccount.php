<?php include("db.php");
class data extends db{
    function __construct() {
        // echo " constructor ";
        echo "</br></br>";
    }


    function addnewuser($name,$pasword,$email,$type){
        $this->name=$name;
        $this->pasword=$pasword;
        $this->email=$email;
        $this->type=$type;


        $q="INSERT INTO userdata(id, name, email, pass,type)VALUES('','$name','$email','$pasword','$type')";

        if($this->connection->exec($q)) {
            header("Location:index.php?msg=New Add done","<font color='red'>");
        }

        else {
            header("Location:admin_service_dashboard.php?msg=Register Fail");
        }



    }
}